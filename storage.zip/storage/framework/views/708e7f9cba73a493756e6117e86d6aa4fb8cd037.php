<?php $__env->startSection('content'); ?>
<div class="content-wrapper">



<form class="m-5" action="<?php echo e(route('tasks.store')); ?>" method="POST">
  <?php echo csrf_field(); ?>
        <div class="input-group mb-3">
          <input type="text" class="form-control" value="<?php echo e(old('nom')); ?>" placeholder="Nom de la tache" name="nom" >
        </div>
        <div class="input-group mb-3">
           <textarea class="form-control" placeholder="Description" rows="6" name="desc" required><?php echo e(old('desc')); ?></textarea>
        </div>
        <div class="input-group mb-3">
          <input type="date" class="form-control" placeholder="Delai" name="delai"  value="<?php echo e(old('delai')); ?>" required>
        </div>
          <!-- /.col -->
          <div class="col-md-12 text-center">
            <button type="submit" style="text-align:center" class="btn btn-primary btn-block">Enregistrer</button>
          </div>

        </div>
      </form>






  </div>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SIL3test\resources\views/dashboard/tasks/create.blade.php ENDPATH**/ ?>