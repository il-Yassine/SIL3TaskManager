<?php $__env->startSection('content'); ?>
<div class="content-wrapper">



<form class="m-5" action="<?php echo e(route('statuses.update',$status->id)); ?>" method="POST">
  <?php echo method_field('PUT'); ?>
  <?php echo csrf_field(); ?>
        <div class="input-group mb-3">
          <input type="text" class="form-control" value="<?php echo e($status->nom); ?>" placeholder="Nom" name="nom" >
        </div>

        <select class="form-control mb-3" name="couleur" required="">
          <option>Selectionnez une couleur</option>
          <option class="bg-primary" value="primary" <?php echo e($status->couleur == "primary" ? "selected" : ""); ?>>primary</option>
          <option class="bg-info" value="info" <?php echo e($status->couleur == "info" ? "selected" : ""); ?>>info</option>
          <option class="bg-success" value="success" <?php echo e($status->couleur == "success" ? "selected" : ""); ?>>success</option>
          <option class="bg-warning" value="warning" <?php echo e($status->couleur == "warning" ? "selected" : ""); ?>>warning</option>
          <option class="bg-secondary" value="secondary" <?php echo e($status->couleur == "secondary" ? "selected" : ""); ?>>secondary</option>
          <option class="bg-danger" value="danger" <?php echo e($status->couleur == "danger" ? "selected" : ""); ?>>danger</option>
        </select>

          <!-- /.col -->
          <div class="col-md-12 text-center">
            <button type="submit" style="text-align:center" class="btn btn-primary btn-block">Enregistrer</button>
          </div>
				
        </div>
      </form>






  </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SIL3test\resources\views/dashboard/status/edit.blade.php ENDPATH**/ ?>