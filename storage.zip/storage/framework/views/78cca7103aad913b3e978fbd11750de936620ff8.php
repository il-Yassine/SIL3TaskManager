

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->


            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Detail des status</h3> <a class="btn btn-primary" href="<?php echo e(route('statuses.edit',$status->id)); ?>">Modifier le status</a> 
                <form class="m-5" action="<?php echo e(route('statuses.destroy',$status->id)); ?>" method="POST">
                  <?php echo method_field('DELETE'); ?>
                  <?php echo csrf_field(); ?>
                  <button type="submit" class="btn btn-danger">Supprimer status</button>
                </form> 
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                id : <?php echo e($status->id); ?><br>
                nom : <?php echo e($status->nom); ?><br>
                couleur : <span class="bg-<?php echo e($status->couleur); ?>"><?php echo e($status->couleur); ?></span> <br>
                Creer le : <?php echo e($status->created_at); ?><br>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SIL3test\resources\views/dashboard/status/show.blade.php ENDPATH**/ ?>