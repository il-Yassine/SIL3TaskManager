<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\SIL3test\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>