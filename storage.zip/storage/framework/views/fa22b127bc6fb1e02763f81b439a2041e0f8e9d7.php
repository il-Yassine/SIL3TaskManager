<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->


            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Détail de l'utilisateur</h3> <a class="btn btn-primary" href="<?php echo e(route('users.edit',$user->id)); ?>">Modifier l' utilisateur</a>
<!--                 <form class="m-5" action="<?php echo e(route('users.destroy',$user->id)); ?>" method="POST">
                  <?php echo method_field('DELETE'); ?>
                  <?php echo csrf_field(); ?>
                  <button type="submit" class="btn btn-danger">Supprimer utilisateur</button>
                </form>  -->
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                id : <?php echo e($user->id); ?><br>
                nom : <?php echo e($user->name); ?><br>
                email : <?php echo e($user->email); ?><br>
                Creer le : <?php echo e($user->created_at); ?><br>
                Liste des taches : <br>
                
                 <br>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SIL3test\resources\views/dashboard/users/show.blade.php ENDPATH**/ ?>