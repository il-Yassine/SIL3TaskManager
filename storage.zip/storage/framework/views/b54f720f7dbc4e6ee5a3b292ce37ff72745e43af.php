<?php $__env->startSection('content'); ?>
<div class="content-wrapper">

    <!-- Content Header (Page header) -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Detail des tâches</h3>
            <a class="btn btn-primary" href="<?php echo e(route('tasks.edit',$task->id)); ?>">Modifier la tache</a>
            <form class="m-5" action="<?php echo e(route('tasks.destroy',$task->id)); ?>" method="POST">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-danger">Supprimer Tache</button>
            </form>
        </div><br>
        <!-- /.card-header -->
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    id : <?php echo e($task->id); ?><br>
                    nom : <?php echo e($task->nom); ?><br>
                    Description : <?php echo e($task->description); ?><br>
                    Delai : <?php echo e($task->delai); ?><br>
                    Creer le : <?php echo e($task->created_at); ?><br>
                    Par : <?php echo e($task->user->name); ?><br>
                </div>
                <div class="col-md-6">

                    <?php $__currentLoopData = $task->statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($status->nom); ?>

                     
                     <br>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>


</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SIL3test\resources\views/dashboard\tasks\show.blade.php ENDPATH**/ ?>